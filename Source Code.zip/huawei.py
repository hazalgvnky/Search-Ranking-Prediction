#!/usr/bin/env python
# coding: utf-8

# In[10]:


import pandas as pd


# In[91]:


mm = pd.read_csv('/Users/macbookretina/Desktop/test_dataset_B.csv',header=None,sep='\t')


# In[95]:


sub = pd.DataFrame(columns=['queryid','documentid','predict_label'])
for index, row in mm.iterrows():
    sub.loc[index]=[row[0],row[1],0]
    print(index)


# In[98]:


import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Activation, Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.metrics import categorical_crossentropy
from sklearn import preprocessing 
from tensorflow import metrics


# In[111]:


model = Sequential([
        Dense(units=8,input_shape=(82,), activation='relu'),
        Dense(units=16,activation='relu'),
        Dense(units=32,activation='relu'),
        Dense(units=4,activation='relu'),
        Dense(units=1,activation='sigmoid')
    ]
    )


# In[113]:


model.compile(loss='binary_crossentropy', optimizer= 'Adam',metrics=['binary_accuracy'])


# In[106]:


#only used text matching columns
df = pd.read_csv(
                '/Users/macbookretina/Desktop/train_dataset.csv',header=None,sep='\t',
                usecols=[0,6,40,41,42,43,44,45,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154]
                )


# In[107]:


labels = df.iloc[:,[0]]
labels = np.array(labels) 
    
        
features = df.iloc[:, 1:]
features = np.array(features)


# In[108]:


scalar = preprocessing.MinMaxScaler()
scaled_feats = scalar.fit_transform(features)
    
features = None


# In[114]:


model.fit(scaled_feats,labels,shuffle=True,validation_split=0.15,batch_size=32)


# In[115]:


test_df = pd.read_csv(
            '/Users/macbookretina/Desktop/test_dataset_B.csv',header=None,sep='\t',
            usecols=[6,40,41,42,43,44,45,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154]
                )


# In[116]:


test_df = np.array(test_df)


# In[117]:


predicted = model.predict(test_df)


# In[118]:


sub['predict_label']=predicted


# In[120]:


sub


# In[121]:


path ="/Users/macbookretina/Desktop/submission.csv"
sub.to_csv(path,index = False)

